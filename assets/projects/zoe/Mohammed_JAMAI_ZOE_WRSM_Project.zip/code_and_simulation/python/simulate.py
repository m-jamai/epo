"""
Time-domain simulation of the field-oriented controlled WRSM.
Author: Mohammed JAMAI

Plant  : dq flux model (states Phi_d, Phi_q, Phi_f), RK4, dt = 10 us
Control: digital, Ts = 1/fsw = 100 us, zero-order hold, one-sample delay
         - Id / Iq PI loops (pole-zero cancellation) + EMF decoupling
         - circular voltage limitation |Vdq| <= Vdc/sqrt(2) (SVPWM) + anti-windup
         - field current PI + coupling feed-forward driving an asymmetric
           half-bridge exciter (Vf in [-Vdc, +Vdc], If > 0)
Speed  : imposed (vehicle inertia >> rotor inertia over the simulated window)
"""
import numpy as np
from zoe_params import MODEL as M, omega_el

Ls, Msr, Lr, Rs, Rr, p = M["Ls"], M["Msr"], M["Lr"], M["Rs"], M["Rr"], M["p"]
LMAT_INV = np.linalg.inv(np.array([[Ls, Msr], [Msr, Lr]]))


def currents(x):
    Id, If = LMAT_INV @ np.array([x[0], x[2]])
    return Id, x[1] / Ls, If


def deriv(x, v, w):
    Id, Iq, If = currents(x)
    Vd, Vq, Vf = v
    return np.array([Vd - Rs * Id + w * x[1],
                     Vq - Rs * Iq - w * x[0],
                     Vf - Rr * If])


def pi_gains():
    Ts = 1.0 / M["fsw"]
    wc = 2 * np.pi * M["fsw"] / 20          # current-loop bandwidth: 500 Hz
    wf = 2 * np.pi * 25.0                    # field-loop bandwidth: 25 Hz
    return dict(Ts=Ts, wc=wc, wf=wf,
                Kp_dq=Ls * wc, Ki_dq=Rs * wc,
                Kp_f=Lr * wf, Ki_f=Rr * wf)


def simulate(Id_ref, Iq_ref, If_ref, n_rpm, t_end=0.3, t_step=0.02,
             premagnetize=True, decouple=True, dt=10e-6, t_ramp=0.02,
             field_ff=True, field_bipolar=True):
    G = pi_gains()
    w = omega_el(n_rpm)
    Vmax = M["Vdq_max"]
    # initial state
    If0 = If_ref if premagnetize else 0.0
    x = np.array([Msr * If0, 0.0, Lr * If0])
    integ = np.zeros(3)
    # start from the steady-state no-load voltage (inverter already synchronised to the EMF)
    v0 = np.array([0.0, w * Msr * If0, Rr * If0])
    mag0 = np.hypot(v0[0], v0[1])
    if mag0 > Vmax: v0[:2] *= Vmax / mag0
    v_cmd = v0.copy(); v_applied = v0.copy()
    n_ctrl = int(round(G["Ts"] / dt))
    N = int(t_end / dt)
    log = {k: np.zeros(N) for k in ["t", "Id", "Iq", "If", "Vd", "Vq", "Vf", "Cem", "ia", "ib", "ic", "Vmag", "sat"]}
    theta = 0.0
    idr_prev = 0.0
    for k in range(N):
        t = k * dt
        if k % n_ctrl == 0:
            Id, Iq, If = currents(x)
            ramp = min(max((t - t_step) / t_ramp, 0.0), 1.0) if t_ramp > 0 else float(t >= t_step)
            idr, iqr = Id_ref * ramp, Iq_ref * ramp      # torque-ramp limited references
            ifr = If_ref
            v_applied = v_cmd.copy()          # one-sample computation delay
            # stator PI
            ed, eq = idr - Id, iqr - Iq
            vd = G["Kp_dq"] * ed + integ[0]
            vq = G["Kp_dq"] * eq + integ[1]
            if decouple:
                vd += -w * Ls * Iq
                vq += w * (Ls * Id + Msr * If)
            mag = np.hypot(vd, vq)
            sat = mag > Vmax
            if sat:
                vd, vq = vd * Vmax / mag, vq * Vmax / mag
            else:
                integ[0] += G["Ki_dq"] * ed * G["Ts"]
                integ[1] += G["Ki_dq"] * eq * G["Ts"]
            # field PI + chopper
            ef = ifr - If
            vf = G["Kp_f"] * ef + integ[2]
            if field_ff:   # stator->rotor coupling compensation: Phi_f = Lr*If + Msr*Id
                vf += Rr * ifr + Msr * (idr - idr_prev) / G["Ts"]
            vf_min = -M["Vbatt"] if field_bipolar else 0.0
            if vf_min <= vf <= M["Vbatt"]:
                integ[2] += G["Ki_f"] * ef * G["Ts"]
            vf = min(max(vf, vf_min), M["Vbatt"])
            idr_prev = idr
            v_cmd = np.array([vd, vq, vf])
        # RK4 plant
        k1 = deriv(x, v_applied, w); k2 = deriv(x + dt / 2 * k1, v_applied, w)
        k3 = deriv(x + dt / 2 * k2, v_applied, w); k4 = deriv(x + dt * k3, v_applied, w)
        x = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        theta += w * dt
        Id, Iq, If = currents(x)
        c = np.sqrt(2 / 3)
        log["t"][k] = t; log["Id"][k] = Id; log["Iq"][k] = Iq; log["If"][k] = If
        log["Vd"][k], log["Vq"][k], log["Vf"][k] = v_applied
        log["Vmag"][k] = np.hypot(v_applied[0], v_applied[1])
        log["sat"][k] = log["Vmag"][k] >= Vmax * 0.999
        log["Cem"][k] = p * (x[0] * Iq - x[1] * Id)
        for j, nm in enumerate(["ia", "ib", "ic"]):
            th = theta - 2 * np.pi * j / 3
            log[nm][k] = c * (Id * np.cos(th) - Iq * np.sin(th))
    return log


if __name__ == "__main__":
    from steady_state import optimal_point
    r = optimal_point(240, 4000)
    lg = simulate(r["Id"], r["Iq"], r["If"], 4000, t_end=0.1)
    i = lg["t"] > 0.08
    print("A: Cem mean", lg["Cem"][i].mean(), "If", lg["If"][i].mean(), "Vmag", lg["Vmag"][i].mean())
