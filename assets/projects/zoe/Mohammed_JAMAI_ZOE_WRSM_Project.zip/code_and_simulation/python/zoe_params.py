"""
ZOE-class wound-rotor synchronous machine (WRSM) traction drive
Author: Mohammed JAMAI  (INP-ENSEEIHT, M1 2EEEA - Mechatronic Systems)

Central parameter file. Every other script imports from here so that a
single change propagates to the sizing, the steady-state optimiser and the
dynamic simulation.
"""
import numpy as np

# ---------------------------------------------------------------------------
# 1. Specification (torque-speed plane)
# ---------------------------------------------------------------------------
POINTS = {           # name: (torque N.m, speed rpm)
    "A": (240.0, 4000.0),   # base point = sizing point (max torque, base speed)
    "B": (80.0, 6700.0),    # partial load, medium speed
    "C": (80.0, 12000.0),   # high speed, constant-power region
}
SIZING_POINT = "A"

# ---------------------------------------------------------------------------
# 2. Electromagnetic design inputs (smooth-pole synchronous machine,
#    indirect air cooling -> Krms 35-80 kA/m, J 3-5 A/mm^2)
# ---------------------------------------------------------------------------
DESIGN = dict(
    p=2,            # pole pairs
    m=3,            # phases
    Nslot=24,       # stator slots (q = 2 slots/pole/phase)
    Krms=80e3,      # rms linear current density [A/m]
    J=5e6,          # rms current density in copper [A/m^2]
    kfill=0.6,      # slot fill factor
    Bm=1.05,        # peak air-gap flux density from rotor [T]
    Bcs=1.7,        # stator yoke flux density [T]
    Bcr=1.7,        # rotor yoke flux density [T]
    Bd=1.8,         # tooth flux density [T]
    e=1e-3,         # air gap [m]
    lam=1.0,        # shape factor: L = 2*lam*a
    kw=0.96,        # winding factor
    kf=0.95,        # lamination stacking factor
    k_endwind=1.3,  # end-winding length factor
    rho_cu=8920.0, rho_fe=7800.0, rho_rotor=7500.0,
    rho_e_cu20=1.72e-8, alpha_cu=3.93e-3, T_cu=120.0,
    n_cond_slot=4,  # conductors per slot (chosen in sizing.py)
)

# ---------------------------------------------------------------------------
# 3. Control-model (dq, power-invariant Park) parameters
#    Msr and Lr come from the original project data (Phi_d0 = Msr*If = 0.135 Wb,
#    Phi_f0 = Lr*If = 20.25 Wb at If = 13.5 A). Rs is derived from the winding
#    design; Ls and Rr are model assumptions (to be identified on a prototype).
# ---------------------------------------------------------------------------
MODEL = dict(
    p=2,
    Rs=2.0e-3,      # stator resistance per phase [ohm] (from winding, 120 degC)
    Ls=0.20e-3,     # synchronous inductance [H]  (assumption)
    Msr=0.010,      # stator-rotor mutual inductance [H] (project data)
    Lr=1.50,        # field winding inductance [H] (project data)
    Rr=10.0,        # field winding resistance [ohm] (assumption)
    Vbatt=400.0,    # DC bus [V]
    fsw=10e3,       # inverter switching frequency [Hz]
    Is_max_rms=513.4,   # phase current limit, rms [A] (value at point A)
    If_max=15.0,        # field current limit [A]
)
# dq (power invariant) magnitudes
MODEL["Idq_max"] = np.sqrt(3) * MODEL["Is_max_rms"]          # 889 A
# SVPWM linear limit: phase peak = Vdc/sqrt(3) -> |Vdq| = sqrt(3/2)*Vdc/sqrt(3)
MODEL["Vdq_max"] = MODEL["Vbatt"] / np.sqrt(2)                # 283 V

# Iron-loss model (Steinmetz-type, M330-35A-class steel, W/kg at 1.5 T, 50 Hz)
IRON = dict(kh=2.3, ke=1.0, B_ref=1.5, f_ref=50.0)
MECH_LOSS = dict(k1=0.5, k3=0.0)   # friction ~ k1*Omega [W per rad/s] (small)


def omega_el(n_rpm, p=MODEL["p"]):
    """Electrical angular frequency [rad/s]."""
    return p * n_rpm * 2 * np.pi / 60.0


def omega_mech(n_rpm):
    return n_rpm * 2 * np.pi / 60.0
