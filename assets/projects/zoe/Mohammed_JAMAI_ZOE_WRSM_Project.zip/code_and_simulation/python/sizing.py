"""
Analytical sizing of the smooth-pole WRSM at the sizing point (A).
Author: Mohammed JAMAI
Reproduces (and corrects the formulas of) the original Excel sizing sheet.
"""
import json, os
import numpy as np
from zoe_params import DESIGN as D, POINTS, SIZING_POINT, MODEL

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results")


def size_machine(Cem=None):
    Cem = Cem or POINTS[SIZING_POINT][0]
    Brms = D["Bm"] / np.sqrt(2)
    Km = D["Krms"] * np.sqrt(2)
    # Torque equation  Cem = pi*kw*a^2*L*Brms*Krms  with L = 2*lam*a
    a = (Cem / (2 * np.pi * D["lam"] * D["kw"] * Brms * D["Krms"])) ** (1 / 3)
    L = 2 * D["lam"] * a
    Cs = a * D["Bm"] / (D["p"] * D["Bcs"])          # stator yoke
    Cr = a * D["Bm"] / (D["p"] * D["Bcr"])          # rotor yoke
    ld = 4 * a * D["Bm"] / (D["Nslot"] * D["Bd"])   # tooth width
    le = 2 * np.pi * a / D["Nslot"] - ld            # slot width
    he = 2 * np.pi * a * D["Krms"] / (D["kfill"] * D["J"] * D["Nslot"] * le)  # slot depth
    Rext = a + he + Cs
    Lpack = L / D["kf"]
    V_tot = np.pi * Rext**2 * Lpack
    V_teeth = D["Nslot"] * ld * he * Lpack
    V_syoke = np.pi * (Rext**2 - (Rext - Cs) ** 2) * Lpack
    V_cu_slot = D["Nslot"] * le * he * D["kfill"] * L
    V_cu = V_cu_slot * D["k_endwind"]
    V_rotor = np.pi * (a - D["e"]) ** 2 * Lpack
    m_syoke = V_syoke * D["rho_fe"]
    m_teeth = V_teeth * D["rho_fe"]
    m_cu = V_cu * D["rho_cu"]
    m_rotor = V_rotor * D["rho_rotor"]
    m_tot = m_syoke + m_teeth + m_cu + m_rotor

    # ---- winding ----------------------------------------------------------
    I_total = 2 * np.pi * a * D["Krms"]             # total rms ampere-conductors
    I_slot = I_total / D["Nslot"]                   # per slot
    S_slot = le * he
    S_cu_slot = D["kfill"] * S_slot
    nc_exact = I_slot / MODEL["Is_max_rms"]
    nc = D["n_cond_slot"]
    S_cond = S_cu_slot / nc
    J_real = MODEL["Is_max_rms"] / S_cond
    N_series = D["Nslot"] * nc / (2 * D["m"])        # turns in series per phase
    l_turn = 2 * L * D["k_endwind"] / D["kf"]        # mean turn length
    rho_T = D["rho_e_cu20"] * (1 + D["alpha_cu"] * (D["T_cu"] - 20))
    Rs = rho_T * N_series * l_turn / S_cond
    # back-EMF constant from geometry (for comparison with the control model)
    tau_p = np.pi * 2 * a / (2 * D["p"])
    phi_pole = (2 / np.pi) * D["Bm"] * tau_p * L
    psi_ph_pk = D["kw"] * N_series * phi_pole
    psi_dq = np.sqrt(3 / 2) * psi_ph_pk

    r = dict(
        Cem=Cem, a=a, D_bore=2 * a, L_active=L, L_stack=Lpack, Cs=Cs, Cr=Cr,
        tooth_width=ld, slot_width=le, slot_depth=he, R_ext=Rext,
        V_total=V_tot, V_teeth=V_teeth, V_stator_yoke=V_syoke, V_cu=V_cu,
        m_stator_yoke=m_syoke, m_teeth=m_teeth, m_cu=m_cu, m_rotor=m_rotor,
        m_total=m_tot, torque_density=Cem / m_tot,
        I_total=I_total, I_slot=I_slot, S_slot=S_slot, S_cu_slot=S_cu_slot,
        nc_exact=nc_exact, nc=nc, S_cond_mm2=S_cond * 1e6, J_real_A_mm2=J_real / 1e6,
        N_series=N_series, l_turn=l_turn, Rs_120C=Rs, psi_dq_geom=psi_dq,
        Km=Km, Brms=Brms,
    )
    return r


if __name__ == "__main__":
    r = size_machine()
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "sizing_results.json"), "w") as f:
        json.dump({k: float(v) for k, v in r.items()}, f, indent=2)
    for k, v in r.items():
        print(f"{k:18s} {v:.6g}")
