"""
Generates every figure and result table of the study.
Author: Mohammed JAMAI
Run:  python make_figures.py      (about 2 minutes)
"""
import os, json, csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Wedge, Circle, FancyBboxPatch, FancyArrowPatch, Rectangle
from zoe_params import MODEL as M, DESIGN as D, POINTS, omega_el, omega_mech
from sizing import size_machine
from steady_state import optimal_point, losses
from simulate import simulate

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "..", "figures"); RES = os.path.join(HERE, "..", "results")
os.makedirs(FIG, exist_ok=True); os.makedirs(RES, exist_ok=True)

NAVY, BLUE, TEAL, ORANGE, RED, GREY = "#14213d", "#2563eb", "#0d9488", "#f59e0b", "#dc2626", "#6b7280"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.grid": True,
                     "grid.alpha": 0.25, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "axes.titlesize": 11, "savefig.dpi": 200,
                     "savefig.bbox": "tight"})
PMAX = POINTS["A"][0] * omega_mech(POINTS["A"][1])     # 100.5 kW system power
NMAX = 12000.0


def spec_torque(n):
    n = np.asarray(n, float)
    return np.minimum(POINTS["A"][0], PMAX / np.maximum(omega_mech(n), 1e-9))


def save(fig, name):
    fig.savefig(os.path.join(FIG, name)); plt.close(fig); print("saved", name)


# --------------------------------------------------------------------------
def draw_section(ax, S, dark=False, legend=True):
    a, he, Rext, e = S["a"] * 1e3, S["slot_depth"] * 1e3, S["R_ext"] * 1e3, D["e"] * 1e3
    txt = "white" if dark else NAVY
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(Circle((0, 0), Rext, color="#cbd5e1", zorder=1))
    ax.add_patch(Circle((0, 0), a, color=(NAVY if dark else "white"), zorder=2))
    N = D["Nslot"]; slot_ang = 360 * S["slot_width"] / (2 * np.pi * S["a"])
    phase_col = [BLUE, ORANGE, TEAL]
    seq = [0, 0, 2, 2, 1, 1]          # 60-degree phase belts, q = 2 slots/pole/phase
    for k in range(N):
        th = 360 * k / N; ph = seq[k % 6]
        ax.add_patch(Wedge((0, 0), a + he, th - slot_ang / 2, th + slot_ang / 2, width=he,
                           color=phase_col[ph], alpha=0.95 if (k // 6) % 2 == 0 else 0.55, zorder=3))
    rr = a - e
    ax.add_patch(Circle((0, 0), rr, color="#94a3b8", zorder=4))
    for j in range(4):
        th = 90 * j + 45
        for sgn in (-1, 1):
            ax.add_patch(Wedge((0, 0), rr - 4, th + sgn * 22 - 6, th + sgn * 22 + 6, width=22, color="#b45309", zorder=5))
        ang = np.radians(90 * j)
        ax.text(0.6 * rr * np.cos(ang), 0.6 * rr * np.sin(ang), "N" if j % 2 == 0 else "S", ha="center",
                va="center", fontsize=14, fontweight="bold", color=NAVY, zorder=6)
    ax.add_patch(Circle((0, 0), 18, color="#475569", zorder=6))
    ax.set_xlim(-Rext * 1.05, Rext * 1.05); ax.set_ylim(-Rext * 1.2, Rext * 1.15)
    ax.text(0, -Rext * 1.13, f"Ø{2*Rext:.0f} mm outer · Ø{2*a:.0f} mm bore · {S['L_stack']*1e3:.0f} mm stack · 24 slots · 4 poles",
            ha="center", fontsize=9, color=txt)
    if legend:
        items = list(zip(phase_col + ["#b45309"], ["Phase a", "Phase b", "Phase c", "Field coil"]))
        for i, (c, lbl) in enumerate(items):
            x = (-0.95 + 0.5 * i) * Rext
            ax.add_patch(Rectangle((x, Rext * 1.04), 8, 8, color=c))
            ax.text(x + 11, Rext * 1.04 + 4, lbl, va="center", fontsize=8, color=txt)


def fig_cross_section(S):
    fig, ax = plt.subplots(figsize=(6.4, 6.6))
    draw_section(ax, S)
    ax.set_title("WRSM cross-section, drawn to scale from the sizing results", color=NAVY, pad=14)
    save(fig, "01_machine_cross_section.png")


def fig_architecture():
    fig, ax = plt.subplots(figsize=(11, 4.2)); ax.axis("off"); ax.set_xlim(0, 110); ax.set_ylim(0, 40)

    def box(x, y, w, h, txt, c):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2", fc=c, ec=NAVY, lw=1.2))
        ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=8.6, color=NAVY)

    def arr(x1, y1, x2, y2, t=""):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=12, lw=1.2, color=NAVY))
        if t:
            if y1 == y2 and y1 > 20: ax.text((x1 + x2) / 2, 37.2, t, ha="center", fontsize=7.5, color=GREY)
            elif y1 == y2: ax.text((x1 + x2) / 2, y1 + 1.2, t, ha="center", fontsize=7.5, color=GREY)
            else: ax.text(x1 + 1, (y1 + y2) / 2, t, ha="left", fontsize=7.5, color=GREY)

    box(1, 26, 14, 9, "Torque demand\nT* , speed Ω", "#e0e7ff")
    box(19, 26, 15, 9, "Loss-optimal\nreference LUT\n(Id*, Iq*, If*)", "#fde68a")
    box(38, 26, 14, 9, "Id / Iq PI\n+ EMF\ndecoupling", "#bfdbfe")
    box(56, 26, 13, 9, "Voltage limit\n|Vdq| ≤ Vdc/√2\n+ anti-windup", "#bfdbfe")
    box(73, 26, 13, 9, "Inverse Park\n+ SVPWM", "#bfdbfe")
    box(90, 26, 18, 9, "3-phase inverter\n(Vdc = 400 V)", "#c7d2fe")
    box(38, 5, 14, 9, "If PI\n+ coupling\nfeed-forward", "#99f6e4")
    box(56, 5, 15, 9, "Asymmetric\nhalf-bridge\nexciter", "#99f6e4")
    box(84, 5, 24, 11, "Wound-rotor\nsynchronous machine\n2 pole pairs", "#fecaca")
    arr(15, 30.5, 19, 30.5); arr(34, 30.5, 38, 30.5, "Id*, Iq*"); arr(52, 30.5, 56, 30.5, "Vd*, Vq*")
    arr(69, 30.5, 73, 30.5); arr(86, 30.5, 90, 30.5, "duty"); arr(99, 26, 99, 16, "Va,b,c")
    ax.plot([26.5, 26.5], [25.6, 9.5], color=NAVY, lw=1.2); arr(26.5, 9.5, 38, 9.5)
    ax.text(28, 11, "If*", fontsize=7.5, color=GREY)
    arr(52, 9.5, 56, 9.5, "Vf*"); arr(71, 9.5, 84, 9.5, "Vf")
    ax.plot([84, 79, 79], [13.5, 13.5, 21], color=GREY, lw=1, ls="--")
    ax.plot([79, 45], [21, 21], color=GREY, lw=1, ls="--"); arr(45, 21, 45, 26)
    ax.text(62, 22, "measured ia,b,c → Park → Id, Iq (θ from resolver)", fontsize=7.5, color=GREY, ha="center")
    ax.plot([84, 81, 81, 45], [7, 7, 2.5, 2.5], color=GREY, lw=1, ls="--"); arr(45, 2.5, 45, 5)
    ax.text(64, 1.0, "measured If", fontsize=7.5, color=GREY, ha="center")
    ax.set_title("Field-oriented control architecture of the WRSM traction drive", color=NAVY, loc="left")
    save(fig, "02_control_architecture.png")


def efficiency_map():
    ns = np.linspace(150, NMAX, 40); Ts = np.linspace(3, 240, 40)
    eff = np.full((len(Ts), len(ns)), np.nan)
    for j, n in enumerate(ns):
        x0 = None
        for i, T in enumerate(Ts):
            r = optimal_point(T, n, x0=x0)
            if r: eff[i, j] = r["eff"]; x0 = [r["Id"], r["Iq"], r["If"]]
    np.savez(os.path.join(RES, "efficiency_map.npz"), n=ns, T=Ts, eff=eff)
    return ns, Ts, eff


def fig_torque_speed(ns, Ts, eff):
    fig, ax = plt.subplots(figsize=(8.6, 5.4))
    lv = [0.80, 0.85, 0.88, 0.90, 0.92, 0.93, 0.94, 0.95, 0.96, 0.965]
    cf = ax.contourf(ns, Ts, eff * 100, levels=np.array([0.0] + lv + [0.98]) * 100, cmap="viridis")
    cs = ax.contour(ns, Ts, eff * 100, levels=np.array(lv) * 100, colors="white", linewidths=0.6)
    ax.clabel(cs, fmt="%.1f", fontsize=7)
    cb = fig.colorbar(cf, ax=ax, pad=0.01, ticks=[80, 85, 88, 90, 92, 93, 94, 95, 96, 96.5]); cf.set_clim(75, 98); cb.set_label("Drive efficiency (motor losses) [%]")
    n = np.linspace(1, NMAX, 400)
    ax.fill_between(n, spec_torque(n), 300, color="white", zorder=2)
    ax.plot(n, spec_torque(n), color=NAVY, lw=2.2, label="Specified envelope (240 N·m / 100.5 kW)", zorder=3)
    from steady_state import max_torque
    cap_n = np.linspace(500, NMAX, 16)
    capv = [max_torque(nn) for nn in cap_n]
    ax.plot(cap_n, capv, color=GREY, lw=1.3, ls="--", zorder=3, label="Electromagnetic capability (current + voltage limits)")
    for k, (T, nn) in POINTS.items():
        ax.plot(nn, T, "o", ms=9, mfc=ORANGE, mec=NAVY, mew=1.5, zorder=5, clip_on=False)
        off = {"A": (8, 8), "B": (-120, -38), "C": (-150, -40)}[k]
        ax.annotate(f"{k}  {T:.0f} N·m @ {nn:.0f} rpm", (nn, T), xytext=off, textcoords="offset points", zorder=6, arrowprops=dict(arrowstyle="-", color=NAVY, lw=0.9),
                    fontsize=9, fontweight="bold", color="white" if k != "A" else NAVY,
                    bbox=dict(boxstyle="round,pad=0.25", fc=NAVY if k != "A" else "white", ec=NAVY, alpha=0.9))
    ax.set_xlim(0, NMAX * 1.02); ax.set_ylim(0, 300)
    ax.set_xlabel("Motor speed [rpm]"); ax.set_ylabel("Torque [N·m]")
    ax.set_title("Torque–speed plane: specification, operating points and loss-optimal efficiency map", color=NAVY, loc="left")
    ax.legend(loc="upper right", fontsize=8, framealpha=0.95); ax.grid(False)
    save(fig, "03_torque_speed_efficiency_map.png")
    return list(zip(cap_n, capv))


def fig_references():
    ns = np.linspace(500, NMAX, 40)
    rows = []
    for T_line, lab in [("env", "Full-load envelope"), (80.0, "80 N·m line (B, C)")]:
        for n in ns:
            T = float(spec_torque(n)) if T_line == "env" else T_line
            r = optimal_point(T, n)
            if r: rows.append((lab, n, T, r["Id"], r["Iq"], r["If"], r["V"], r["eff"]))
    with open(os.path.join(RES, "optimal_references.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["curve", "speed_rpm", "torque_Nm", "Id_A", "Iq_A", "If_A", "Vdq_V", "efficiency"])
        w.writerows(rows)
    fig, axs = plt.subplots(1, 3, figsize=(12, 3.8))
    for lab, ls in [("Full-load envelope", "-"), ("80 N·m line (B, C)", "--")]:
        d = np.array([r[1:] for r in rows if r[0] == lab])
        axs[0].plot(d[:, 0], d[:, 2], color=RED, ls=ls); axs[0].plot(d[:, 0], d[:, 3], color=BLUE, ls=ls)
        axs[1].plot(d[:, 0], d[:, 4], color=TEAL, ls=ls, label=lab)
        axs[2].plot(d[:, 0], d[:, 5], color=NAVY, ls=ls, label=lab)
    axs[0].axhline(0, color="k", lw=0.6)
    axs[0].text(9000, 600, "Iq", color=BLUE, fontweight="bold"); axs[0].text(9000, -380, "Id", color=RED, fontweight="bold")
    axs[0].set_title("Stator currents (dq) [A]"); axs[1].set_title("Field current If [A]")
    axs[2].axhline(M["Vdq_max"], color=RED, lw=1, ls=":"); axs[2].text(600, M["Vdq_max"] + 5, "inverter limit Vdc/√2 = 283 V", fontsize=8, color=RED)
    axs[2].set_title("Stator voltage |Vdq| [V]"); axs[2].set_ylim(0, 320)
    axs[1].legend(fontsize=8); [a.set_xlabel("Speed [rpm]") for a in axs]
    fig.suptitle("Loss-optimal references: the WRSM shares flux weakening between If and Id", color=NAVY, fontweight="bold", x=0.01, ha="left")
    fig.tight_layout(); save(fig, "04_optimal_references_vs_speed.png")


def fig_point_A():
    r = optimal_point(*POINTS["A"])
    lg = simulate(r["Id"], r["Iq"], r["If"], POINTS["A"][1], t_end=0.12)
    t = lg["t"] * 1e3
    fig, axs = plt.subplots(2, 2, figsize=(11, 6.2))
    axs[0, 0].plot(t, lg["Cem"], color=NAVY); axs[0, 0].axhline(240, color=ORANGE, ls="--", lw=1)
    axs[0, 0].set_title("Electromagnetic torque [N·m]")
    axs[0, 1].plot(t, lg["Id"], color=RED, label="Id"); axs[0, 1].plot(t, lg["Iq"], color=BLUE, label="Iq")
    axs[0, 1].legend(fontsize=8); axs[0, 1].set_title("dq currents [A]")
    axs[1, 0].plot(t, lg["If"], color=TEAL); axs[1, 0].set_ylim(0, 20); axs[1, 0].set_title("Field current If [A]")
    m = (t > 90) & (t < 105)
    for nm, c in zip(["ia", "ib", "ic"], [BLUE, ORANGE, TEAL]): axs[1, 1].plot(t[m], lg[nm][m], color=c, label=nm)
    axs[1, 1].legend(fontsize=8, ncol=3); axs[1, 1].set_title("Phase currents, steady state [A]")
    for a in axs.flat: a.set_xlabel("Time [ms]")
    fig.suptitle(f"Point A (240 N·m, 4000 rpm): torque ramp 20 ms, overshoot {100*(lg['Cem'].max()/240-1):.1f} %", color=NAVY, fontweight="bold", x=0.01, ha="left")
    fig.tight_layout(); save(fig, "05_point_A_transient.png")
    return lg, r


def fig_premag():
    r = optimal_point(*POINTS["A"])
    a = simulate(r["Id"], r["Iq"], r["If"], 4000, t_end=0.25, premagnetize=True)
    b = simulate(r["Id"], r["Iq"], r["If"], 4000, t_end=0.25, premagnetize=False)
    fig, axs = plt.subplots(1, 2, figsize=(11, 3.6))
    axs[0].plot(b["t"] * 1e3, b["Cem"], color=GREY, label="Rotor not pre-magnetised")
    axs[0].plot(a["t"] * 1e3, a["Cem"], color=NAVY, label="Rotor pre-magnetised (If = If*)")
    axs[0].set_title("Torque [N·m]"); axs[0].legend(fontsize=8)
    axs[1].plot(b["t"] * 1e3, b["If"], color=GREY); axs[1].plot(a["t"] * 1e3, a["If"], color=NAVY)
    axs[1].set_title("Field current [A]")
    for x in axs: x.set_xlabel("Time [ms]")
    fig.suptitle("Why the rotor must be magnetised before torque is requested (τ_field = Lr/Rr = 150 ms)", color=NAVY, fontweight="bold", x=0.01, ha="left")
    fig.tight_layout(); save(fig, "06_premagnetisation.png")


def fig_point_C():
    T, n = POINTS["C"]
    r = optimal_point(T, n)
    nofw = simulate(0.0, T / (M["p"] * M["Msr"] * 13.5), 13.5, n, t_end=0.1)
    fw = simulate(r["Id"], r["Iq"], r["If"], n, t_end=0.1)
    fig, axs = plt.subplots(1, 3, figsize=(12.5, 3.8))
    for lg, c, lab in [(nofw, RED, "No flux weakening (If = 13.5 A, Id = 0)"), (fw, NAVY, "Loss-optimal flux weakening")]:
        axs[0].plot(lg["t"] * 1e3, lg["Cem"], color=c, label=lab)
        axs[1].plot(lg["t"] * 1e3, lg["Vmag"], color=c)
        axs[2].plot(lg["t"] * 1e3, np.hypot(lg["Id"], lg["Iq"]) / np.sqrt(3), color=c)
    axs[0].axhline(80, color=ORANGE, ls="--", lw=1); axs[0].legend(fontsize=7.5, loc="lower right")
    axs[1].axhline(M["Vdq_max"], color=GREY, ls=":"); axs[1].set_ylim(0, 320)
    axs[0].set_title("Torque [N·m]"); axs[1].set_title("|Vdq| applied [V]"); axs[2].set_title("Phase current, rms [A]")
    for x in axs: x.set_xlabel("Time [ms]")
    fig.suptitle("Point C (80 N·m, 12 000 rpm): back-EMF 339 V > 283 V available, so flux weakening is mandatory",
                 color=NAVY, fontweight="bold", x=0.01, ha="left")
    fig.tight_layout(); save(fig, "07_point_C_flux_weakening.png")
    return nofw, fw, r


def fig_losses():
    labels, opt, ref = [], [], []
    for k, (T, n) in POINTS.items():
        o = optimal_point(T, n); c = optimal_point(T, n, If_fixed=13.5, Id_zero=True)
        labels.append(k); opt.append(o); ref.append(c)
    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    comp = [("cu_s", "Stator copper", BLUE), ("cu_r", "Rotor copper", TEAL), ("fe", "Iron", ORANGE), ("mech", "Mechanical", GREY)]
    x = np.arange(len(labels)); w = 0.36
    for off, data, hatch, nm in [(-w / 2, ref, "//", "Classical: If = 13.5 A, Id = 0"), (w / 2, opt, "", "Loss-optimal (Id, Iq, If)")]:
        bottom = np.zeros(len(labels))
        for key, lab, c in comp:
            vals = np.array([d["losses"][key] / 1e3 if d else 0 for d in data])
            ax.bar(x + off, vals, w, bottom=bottom, color=c, hatch=hatch, edgecolor="white",
                   label=lab if off > 0 else None)
            bottom += vals
        for i, d in enumerate(data):
            txt = f"η = {100*d['eff']:.1f} %" if d else "not\nreachable"
            ax.text(x[i] + off, (bottom[i] if d else 0) + 0.12, txt, ha="center", fontsize=8, color=NAVY)
    ax.set_xticks(x); ax.set_xticklabels([f"Point {l}\n{POINTS[l][0]:.0f} N·m, {POINTS[l][1]:.0f} rpm" for l in labels])
    ax.set_ylabel("Losses [kW]"); ax.legend(fontsize=8, ncol=2, loc="upper left")
    ax.text(0.99, 0.97, "hatched = classical strategy · solid = loss-optimal", transform=ax.transAxes, ha="right", va="top", fontsize=8, color=GREY)
    ax.set_ylim(0, 7.5)
    ax.set_title("Loss breakdown: what the extra degree of freedom of the wound rotor buys", color=NAVY, loc="left")
    save(fig, "08_loss_breakdown.png")
    return opt, ref


def vehicle():
    m, Crr, CdA, rho, rw, G, eta_g, kin = 1577.0, 0.010, 0.75, 1.2, 0.317, 9.32, 0.97, 1.06
    dt = 0.01; v = 0.0; t = 0.0; T_, V_ = [0.0], [0.0]; t100 = None
    while t < 25:
        n = v / rw * G * 60 / (2 * np.pi)
        if n >= NMAX: Tm = 0.0
        else: Tm = float(spec_torque(max(n, 1)))
        F = Tm * G * eta_g / rw - (m * 9.81 * Crr + 0.5 * rho * CdA * v**2)
        v = max(v + F / (m * kin) * dt, 0); t += dt
        T_.append(t); V_.append(v * 3.6)
        if t100 is None and v * 3.6 >= 100: t100 = t
    vmax = NMAX / G * 2 * np.pi / 60 * rw * 3.6
    fig, ax = plt.subplots(figsize=(7.5, 3.8))
    ax.plot(T_, V_, color=NAVY, lw=2)
    ax.axhline(100, color=GREY, ls=":"); ax.axvline(t100, color=ORANGE, ls="--")
    ax.text(t100 + 0.3, 40, f"0–100 km/h ≈ {t100:.1f} s", color=ORANGE, fontweight="bold")
    ax.text(14, vmax - 12, f"motor-speed limit ≈ {vmax:.0f} km/h", color=NAVY)
    ax.set_xlabel("Time [s]"); ax.set_ylabel("Vehicle speed [km/h]")
    ax.set_title("Quasi-static full-throttle acceleration, 1577 kg B-segment EV, gear 9.32", color=NAVY, loc="left")
    save(fig, "09_vehicle_acceleration.png")
    return t100, vmax


def fig_hero(S, opt, t100):
    fig = plt.figure(figsize=(12, 6.3)); fig.patch.set_facecolor(NAVY)
    ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off"); ax.set_xlim(0, 120); ax.set_ylim(0, 63)
    ax.text(4, 55, "Wound-Rotor Synchronous Traction Drive", color="white", fontsize=24, fontweight="bold")
    ax.text(4, 50, "Sizing · dq modelling · field-oriented control · loss-optimal flux weakening  —  ZOE-class B-segment EV",
            color="#cbd5e1", fontsize=12)
    ax.text(4, 45.5, "Mohammed JAMAI  ·  INP-ENSEEIHT, M1 2EEEA Mechatronic Systems  ·  Python / MATLAB-Simulink", color=ORANGE, fontsize=11)
    kpis = [(f"{POINTS['A'][0]:.0f} N·m", "peak torque"), (f"{PMAX/1e3:.0f} kW", "constant power, 4–12 krpm"),
            (f"{S['m_total']:.0f} kg", "active mass (sizing)"), (f"{100*opt[2]['eff']:.1f} %", "efficiency at point C"),
            ("< 1 %", "torque overshoot (FOC)"), (f"{t100:.1f} s", "0–100 km/h (quasi-static)")]
    for i, (v, l) in enumerate(kpis):
        x = 4 + (i % 3) * 19.5; y = 27 - (i // 3) * 15
        ax.add_patch(FancyBboxPatch((x, y), 17.5, 11.5, boxstyle="round,pad=0.3,rounding_size=1.5", fc="#1e2d4f", ec="#334155"))
        ax.text(x + 8.75, y + 7, v, color="white", fontsize=19, fontweight="bold", ha="center")
        ax.text(x + 8.75, y + 2.5, l, color="#94a3b8", fontsize=8.5, ha="center")
    sub = fig.add_axes([0.6, 0.02, 0.38, 0.72]); sub.set_facecolor(NAVY)
    draw_section(sub, S, dark=True, legend=False)
    fig.savefig(os.path.join(FIG, "00_portfolio_cover.png"), facecolor=NAVY); plt.close(fig); print("saved cover")


if __name__ == "__main__":
    S = size_machine()
    fig_cross_section(S); fig_architecture()
    ns, Ts, eff = efficiency_map()
    cap = fig_torque_speed(ns, Ts, eff)
    fig_references()
    lgA, rA = fig_point_A(); fig_premag()
    nofw, fw, rC = fig_point_C()
    opt, ref = fig_losses()
    t100, vmax = vehicle()
    fig_hero(S, opt, t100)
    summ = {"points": {}, "t_0_100_s": t100, "vmax_kmh": vmax, "capability": cap,
            "pi": {k: float(v) for k, v in __import__("simulate").pi_gains().items()}}
    for (k, o), c in zip(zip(POINTS.keys(), opt), ref):
        summ["points"][k] = {"optimal": {kk: (float(vv) if not isinstance(vv, dict) else {a: float(b) for a, b in vv.items()}) for kk, vv in o.items()},
                             "classical": None if c is None else {kk: (float(vv) if not isinstance(vv, dict) else {a: float(b) for a, b in vv.items()}) for kk, vv in c.items()}}
    i = lgA["t"] > 0.08
    summ["A_sim"] = dict(Cem_mean=float(lgA["Cem"][i].mean()), Cem_ripple_pp=float(np.ptp(lgA["Cem"][i])), overshoot=float(lgA["Cem"].max() / 240 - 1))
    i = fw["t"] > 0.08
    summ["C_sim"] = dict(fw_Cem=float(fw["Cem"][i].mean()), fw_overshoot=float(fw["Cem"].max() / 80 - 1),
                         nofw_Cem=float(nofw["Cem"][i].mean()), nofw_I=float(np.hypot(nofw["Id"], nofw["Iq"])[i].mean() / np.sqrt(3)))
    with open(os.path.join(RES, "summary.json"), "w") as f: json.dump(summ, f, indent=2)
    print(json.dumps({k: v for k, v in summ.items() if k != "points"}, indent=1))
