"""
Steady-state dq model, operating limits and loss-optimal current references.
Author: Mohammed JAMAI

For a smooth-pole WRSM (Ld = Lq = Ls), power-invariant Park transform:
    Phi_d = Ls*Id + Msr*If          Phi_q = Ls*Iq
    Vd = Rs*Id - w*Ls*Iq            Vq = Rs*Iq + w*(Ls*Id + Msr*If)
    Cem = p*Msr*If*Iq               Vf = Rr*If
The WRSM has three control variables (Id, Iq, If) for one torque demand:
the two extra degrees of freedom are used to minimise losses while
respecting |Idq| <= Idq_max, If <= If_max and |Vdq| <= Vdq_max.
"""
import numpy as np
from scipy.optimize import minimize
from zoe_params import MODEL as M, IRON, MECH_LOSS, omega_el, omega_mech
from sizing import size_machine

_S = size_machine()
M_IRON = _S["m_stator_yoke"] + _S["m_teeth"]
PSI_BASE = M["Msr"] * 13.5          # flux linkage at which yoke B ~ 1.7 T (design point)


def voltages(Id, Iq, If, n):
    w = omega_el(n)
    Vd = M["Rs"] * Id - w * M["Ls"] * Iq
    Vq = M["Rs"] * Iq + w * (M["Ls"] * Id + M["Msr"] * If)
    return Vd, Vq


def flux_mag(Id, Iq, If):
    return np.hypot(M["Ls"] * Id + M["Msr"] * If, M["Ls"] * Iq)


def losses(Id, Iq, If, n):
    p_cu_s = M["Rs"] * (Id**2 + Iq**2)
    p_cu_r = M["Rr"] * If**2
    f = omega_el(n) / (2 * np.pi)
    B = 1.7 * flux_mag(Id, Iq, If) / PSI_BASE
    fr = f / IRON["f_ref"]; br = (B / IRON["B_ref"]) ** 2
    p_fe = M_IRON * (IRON["kh"] * fr * br + IRON["ke"] * fr**2 * br)
    p_mech = MECH_LOSS["k1"] * omega_mech(n)
    return dict(cu_s=p_cu_s, cu_r=p_cu_r, fe=p_fe, mech=p_mech,
                total=p_cu_s + p_cu_r + p_fe + p_mech)


def torque(Iq, If):
    return M["p"] * M["Msr"] * If * Iq


def optimal_point(T, n, If_fixed=None, Id_zero=False, x0=None):
    """Minimise total losses for torque T [N.m] at speed n [rpm].
    Returns dict or None if infeasible."""
    Imax, Vmax, Ifmax = M["Idq_max"], M["Vdq_max"] * 0.98, M["If_max"]

    def unpack(x):
        Id, Iq, If = x
        if If_fixed is not None: If = If_fixed
        if Id_zero: Id = 0.0
        return Id, Iq, If

    obj = lambda x: losses(*unpack(x), n)["total"] / 1e3
    cons = [
        {"type": "eq", "fun": lambda x: (torque(unpack(x)[1], unpack(x)[2]) - T) / 10},
        {"type": "ineq", "fun": lambda x: (Imax**2 - unpack(x)[0]**2 - unpack(x)[1]**2) / 1e5},
        {"type": "ineq", "fun": lambda x: (Vmax**2 - np.sum(np.square(voltages(*unpack(x), n)))) / 1e4},
    ]
    bounds = [(-Imax, 0.0), (0.0, Imax), (0.3, Ifmax)]
    starts = [x0] if x0 is not None else []
    starts += [[0.0, T / (M["p"] * M["Msr"] * 13.5), 13.5],
               [-200.0, T / (M["p"] * M["Msr"] * 8.0), 8.0],
               [-500.0, T / (M["p"] * M["Msr"] * 5.0), 5.0],
               [-700.0, min(Imax * 0.6, T / (M["p"] * M["Msr"] * 3.0)), 3.0]]
    best = None
    for s in starts:
        r = minimize(obj, s, method="SLSQP", bounds=bounds, constraints=cons,
                     options=dict(maxiter=300, ftol=1e-9))
        if not r.success:
            continue
        Id, Iq, If = unpack(r.x)
        ok = (abs(torque(Iq, If) - T) < 0.5 and Id**2 + Iq**2 <= Imax**2 * 1.001 and
              np.sum(np.square(voltages(Id, Iq, If, n))) <= (M["Vdq_max"]) ** 2 * 1.001)
        if ok and (best is None or r.fun < best[0]):
            best = (r.fun, Id, Iq, If)
    if best is None:
        return None
    _, Id, Iq, If = best
    Vd, Vq = voltages(Id, Iq, If, n)
    L = losses(Id, Iq, If, n)
    Pm = T * omega_mech(n)
    return dict(T=T, n=n, Id=Id, Iq=Iq, If=If, Is_rms=np.hypot(Id, Iq) / np.sqrt(3),
                Vd=Vd, Vq=Vq, V=np.hypot(Vd, Vq), Pmech=Pm, losses=L,
                eff=Pm / (Pm + L["total"]),
                pf=(Vd * Id + Vq * Iq) / (np.hypot(Vd, Vq) * np.hypot(Id, Iq)),
                psi=np.degrees(np.arctan2(-Id, Iq)))


def max_torque(n):
    """Maximum torque reachable at speed n (bisection on feasibility)."""
    lo, hi = 0.0, 300.0
    for _ in range(18):
        mid = 0.5 * (lo + hi)
        if optimal_point(mid, n) is not None: lo = mid
        else: hi = mid
    return lo


if __name__ == "__main__":
    from zoe_params import POINTS
    for k, (T, n) in POINTS.items():
        r = optimal_point(T, n)
        r13 = optimal_point(T, n, If_fixed=13.5, Id_zero=True)
        print(k, "opt:", {kk: (round(v, 3) if isinstance(v, float) else v) for kk, v in r.items() if kk != "losses"})
        print("   losses", {kk: round(v, 1) for kk, v in r["losses"].items()})
        print("   If=13.5,Id=0:", None if r13 is None else (round(r13['eff'], 4), round(r13['V'], 1)))
